package text;

import java.util.Scanner;

public class Driver {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan=new Scanner(System.in);
		System.out.println("ѧ��:");
		int semester1 = scan.nextInt();
		
		System.out.println("ѧ��:");
		int year1 = scan.nextInt();
		
		System.out.println("�γ����ƣ�");
		String subjectName1 = scan.nextLine();
		
		System.out.println("�γ�ID��");
		int subjectId1 =scan.nextInt();
		
		System.out.println("ѧ��ID��");
		String studentId1 =scan.nextLine();
		
		System.out.println("ѧ��������");
		String studentName1 = scan.nextLine();
		
		Student student1;
		Subject subject1;
		Classlist classlist1;
		//��������
		student1 = new Student (studentName1,studentId1);
		
	     subject1 = new Subject(subjectId1,subjectName1 );
		
	     classlist1 =new Classlist(semester1,year1);
		
		String detail1 =classlist1.toString();
		System.out.println(detail1);
		String detail2 = subject1.toString();
		System.out.println(detail2);
		String detail3 = student1.toString();
		System.out.println(detail3);
		
				
		
		
		
	}

}
