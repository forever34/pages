package text;

public class Classlist {
	private int semester;
	private int year;
	
	
	public Classlist(int semester, int year) {
		super();
		this.semester = semester;
		this.year = year;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int semester) {
		this.semester = semester;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	@Override
	public String toString() {
		return "Classlist [semester=" + semester + ", year=" + year + "]";
	}
	
	
	
	

}
