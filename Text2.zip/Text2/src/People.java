
public class People {
	private String peopleId;
	private String name;
	private DepositCard depositCard1;//�洢���Ķ���
	private CreditCard  creditCard1;
	
	public People(String peopleId, String name, DepositCard depositCard1, CreditCard creditCard1) {
		super();
		this.peopleId = peopleId;
		this.name = name;
		this.depositCard1 = depositCard1;
		this.creditCard1 = creditCard1;
	}
	public String getPeopleId() {
		return peopleId;
	}
	public void setPeopleId(String peopleId) {
		this.peopleId = peopleId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public DepositCard getDepositCard1() {
		return depositCard1;
	}
	public void setDepositCard1(DepositCard depositCard1) {
		this.depositCard1 = depositCard1;
	}
	public CreditCard getCreditCard1() {
		return creditCard1;
	}
	public void setCreditCard1(CreditCard creditCard1) {
		this.creditCard1 = creditCard1;
	}
	@Override
	public String toString() {
		return "People [peopleId=" + peopleId + ", name=" + name + ", depositCard1=" + depositCard1 + ", creditCard1="
				+ creditCard1 + "]";
	}
	
	

}
